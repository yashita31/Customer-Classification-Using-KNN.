# Customers-segmentation-using-KNN-model-
Topic: A classification approach to categorize the customers using KNN model of Machine Learning.
Tried to achieve score >7 with greater frequency value using K means
